-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 15, 2015 at 11:50 AM
-- Server version: 5.6.25
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rmg_tool`
--

-- --------------------------------------------------------

--
-- Table structure for table `m_project_master`
--

CREATE TABLE IF NOT EXISTS `m_project_master` (
  `project_code` int(9) NOT NULL COMMENT '9 Digit project code',
  `sector` varchar(5) NOT NULL,
  `project_status` varchar(10) NOT NULL,
  `project_manager` varchar(255) NOT NULL COMMENT 'Email-ID of project Manager',
  `eng_manager` varchar(255) NOT NULL COMMENT 'Email-ID of Engagement Manger',
  `sector_lead` varchar(255) NOT NULL COMMENT 'Email-ID of Sector Lead'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `m_project_master`
--

INSERT INTO `m_project_master` (`project_code`, `sector`, `project_status`, `project_manager`, `eng_manager`, `sector_lead`) VALUES
(100248531, 'EUC', 'ACTIVE', 'sumit.naik@capgemini.com', 'sanjay.vaidya@capgemini.com', 'rajendra.thakur@capgemini.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `m_project_master`
--
ALTER TABLE `m_project_master`
  ADD PRIMARY KEY (`project_code`,`sector`,`project_status`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
