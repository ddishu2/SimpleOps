-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 15, 2015 at 11:49 AM
-- Server version: 5.6.25
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rmg_tool`
--

-- --------------------------------------------------------

--
-- Table structure for table `m_notifications_config`
--

CREATE TABLE IF NOT EXISTS `m_notifications_config` (
  `action_type` varchar(5) NOT NULL,
  `capability` varchar(50) NOT NULL,
  `BU` varchar(40) NOT NULL DEFAULT '',
  `capability_lead` varchar(1) NOT NULL,
  `capability_sub_lead` varchar(1) NOT NULL,
  `capability_SPOC` varchar(1) NOT NULL,
  `capability_gen_id` varchar(1) NOT NULL,
  `ops_lead` varchar(1) NOT NULL,
  `ops_sub_lead` varchar(1) NOT NULL,
  `ops_gen_id` varchar(1) NOT NULL,
  `so_creator` varchar(1) NOT NULL,
  `proj_manager` varchar(1) NOT NULL,
  `eng_manager` varchar(1) NOT NULL,
  `resource` varchar(1) NOT NULL,
  `bu_lead` varchar(1) NOT NULL,
  `lead_other_bu` varchar(1) NOT NULL,
  `crmg` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `m_notifications_config`
--
ALTER TABLE `m_notifications_config`
  ADD PRIMARY KEY (`action_type`,`capability`,`BU`),
  ADD UNIQUE KEY `action_type` (`action_type`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
