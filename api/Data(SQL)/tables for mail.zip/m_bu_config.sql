-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 16, 2015 at 12:38 PM
-- Server version: 5.6.25
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rmg_tool`
--

-- --------------------------------------------------------

--
-- Table structure for table `m_bu_config`
--

CREATE TABLE IF NOT EXISTS `m_bu_config` (
  `sr_no` int(11) NOT NULL,
  `BU` varchar(40) NOT NULL,
  `lead` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `m_bu_config`
--

INSERT INTO `m_bu_config` (`sr_no`, `BU`, `lead`) VALUES
(1, 'AppsOne SAP', 'vijay.shanbhag@capgemini.com'),
(2, 'AppsOne AM', 'ashutosh.misra@capgemini.com'),
(3, 'AppsOne Oracle', 'ravikanth.kodali@capgemini.com'),
(4, 'AppsOne CSD', 'clifton.menezes@capgemini.com'),
(5, 'LBS', ''),
(6, 'Testing', ''),
(7, 'Transversal', ''),
(7, 'AppsTwo SAP', ''),
(8, 'Sogeti', ''),
(9, 'Financial Services', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
