-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 16, 2015 at 12:38 PM
-- Server version: 5.6.25
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rmg_tool`
--

-- --------------------------------------------------------

--
-- Table structure for table `m_capability_config`
--

CREATE TABLE IF NOT EXISTS `m_capability_config` (
  `sr_no` int(11) NOT NULL,
  `BU` varchar(40) NOT NULL,
  `capability` varchar(50) NOT NULL,
  `lead` varchar(255) NOT NULL,
  `sub_lead_1` varchar(255) NOT NULL,
  `sub_lead_2` varchar(255) NOT NULL,
  `staffing_spoc_1` varchar(255) NOT NULL,
  `staffing_spoc_2` varchar(255) NOT NULL,
  `generic_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `m_capability_config`
--

INSERT INTO `m_capability_config` (`sr_no`, `BU`, `capability`, `lead`, `sub_lead_1`, `sub_lead_2`, `staffing_spoc_1`, `staffing_spoc_2`, `generic_id`) VALUES
(1, 'AppsOne SAP', 'Finance', 'achyut.bal@capgemini.com', '', '', '', '', ''),
(2, 'AppsOne SAP', 'SCM', 'swanand.bhedasgaonkar@capgemini.com', '', '', '', '', ''),
(3, 'AppsOne SAP', 'DCM', 'avinash.karve@capgemini.com', 'chirdeep.rastogi@capgemini.com', 'pravin.raut@capgemini.com', 'yogesh.kathe@capgemini.com', 'chinmay.tank@capgemini.com', 'appsonesapcrmstaffing.in@capgemini.com'),
(4, 'AppsOne SAP', 'Net Weaver', 'atul.khavanekar@capgemini.com', '', '', '', '', ''),
(5, 'AppsOne SAP', 'Development', 'yadav.kulkarni@capgemini.com', '', '', '', '', ''),
(6, 'AppsOne SAP', 'HCM', 'swetank.singh@capgemini.com', '', '', '', '', ''),
(8, 'AppsOne SAP', 'Retail ', 'alok.sen@capgemini.com', '', '', '', '', ''),
(9, 'AppsOne SAP', 'ISU', 'renju.pillai@capgemini.com', '', '', '', '', ''),
(10, 'AppsOne SAP', 'Operations', 'hemant.c.kumar@capgemini.com', 'alice.kolatkar@capgemini.com', 'praveen.kumaran@capgemini.com', 'seema.tawade@capgemini.com', 'sneha.vaze@capgemini.com', 'appsonesap.in@capgemini.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `m_capability_config`
--
ALTER TABLE `m_capability_config`
  ADD PRIMARY KEY (`sr_no`,`BU`,`capability`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
