-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 16, 2015 at 12:37 PM
-- Server version: 5.6.25
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rmg_tool`
--

-- --------------------------------------------------------

--
-- Table structure for table `t_act_type_text`
--

CREATE TABLE IF NOT EXISTS `t_act_type_text` (
  `action_type` varchar(5) NOT NULL,
  `action_type_text` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_act_type_text`
--

INSERT INTO `t_act_type_text` (`action_type`, `action_type_text`) VALUES
('BUTA', 'BU Transfer Approval'),
('CRD', 'Change in Release date'),
('CTE', 'Change in T&E approver'),
('HL', 'Hard lock'),
('RL2', 'Resource release ? 2 days'),
('RL4', 'Resource release ? 4 weeks notice'),
('RT', 'Resource tagging '),
('SL', 'Soft lock '),
('SLR', 'Soft lock release');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `t_act_type_text`
--
ALTER TABLE `t_act_type_text`
  ADD PRIMARY KEY (`action_type`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
