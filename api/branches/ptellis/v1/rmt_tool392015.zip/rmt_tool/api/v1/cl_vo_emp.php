<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of cl_vo_emp
 *
 * @author ptellis
 */

//require __DIR__.DIRECTORY_SEPARATOR.'cl_vo_open_so.php';
class cl_vo_deployablEmployee {
     static public function get(     $fp_so_id        = null,
                                    $fp_arr_skill    = null,
                                    $fp_arr_location = null, 
                                    $fp_arr_level    = null, 
                                    $fp_startdate    = null, 
                                    $fp_enddate      = null
                                    
                                )
    {
         $emp = [];
        for ($i = 0 ; $i < count($fp_so_id); $i++)
    {
         
        $wa_emp['key'] = $fp_so_id[$i];
        
        $loc = $fp_arr_location[$i];
        $lvl = $fp_arr_level[$i] ;
        $skill = $fp_arr_skill[$i] ;
        
        $sql1 = "SELECT * FROM `v_deployable_emps`
                where
                org = '$loc'
                and
                level = '$lvl'
                and 
                skill1_l4 = '$skill'
                ORDER BY hire_date
                LIMIT 1";
        $wa_emp['value']= cl_DB::getResultsFromQuery($sql1);       
        $emp[] = $wa_emp; 

        
        }
        
       return $emp; 
        
            
    }
    
    static public function get_emps($fp_so_start_date = NULL,
                               $fp_so_end_date   = NULL
                                     )
    {
        $fp_so_id        = array();
        $fp_arr_skill    = array();
        $fp_arr_location = array(); 
        $fp_arr_level    = array(); 
        $fp_startdate    = array(); 
        $fp_enddate      = array();
        
      
         $re_result = cl_vo_open_so::get($fp_so_start_date, $fp_so_end_date);
        
         
        for($i = 0; $i <  count($re_result)-2;$i++)
        {
            $fp_so_id[$i] = $re_result[$i]["so_no"];
            $fp_arr_skill[$i] = $re_result[$i]["skill1"];
            $fp_arr_location[$i] = $re_result[$i]["so_loc"];
            $fp_startdate[$i] = $re_result[$i]["so_sdate"];
            $fp_enddate[$i] = $re_result[$i]["so_endate"];
            $fp_arr_level[$i] = $re_result[$i]["grade"];
            
        }
        $lt_emp = cl_vo_deployablEmployee::get($fp_so_id,$fp_arr_skill , $fp_arr_location, $fp_arr_level ,$fp_startdate , $fp_enddate);
          return $lt_emp;
    }
   
    
    
    
    
    public function __construct($fp_v_empid)
    {
        
    }
    
    public function validate()
    {
        
    }
    
    public function isDeployable()
    {
        
    }
    
    private function isEmpIDValid()
    {
        
    }
    
    public function amendStartDate()
    {
        
    }
    
    public function amendEndDate()
    {
        
    }
    
    public function amend_T_and_E()
    {
        
    }
    
    public function amend_skill() {
        
    }

}
