<?php

//Include Slim Framework Library Code
class cl_RMGTool_Globals
{
    const GC_APP_NAME               = 'RMGTool_REST_API';
//    const GC_ROUTE_OPEN_SO        = '/open_so(/:from_date)(/:to_date)'; 
    const GC_ROUTE_OPEN_SO          = '/open_so(/)'; 
    const GC_ROUTE_DEPLOYABLE_EMPS  = '/deployable_emp(/)'; 
    const GC_ROUTE_EMP_FOR_SO       = '/emps_for_open_so(/)'; 
    const OPEN_SO_DATE_RANGE    = 21;
    const GC_SINGLE_EMP = '/sing_emp(/)';
}
//Include Slim.php library files
require __DIR__.
                                DIRECTORY_SEPARATOR.
                                'libraries'.
                                DIRECTORY_SEPARATOR.
                                'Slim'.
                                DIRECTORY_SEPARATOR.
                                'Slim.php';;
require __DIR__.DIRECTORY_SEPARATOR.'cl_DB.php';
require __DIR__.DIRECTORY_SEPARATOR.'cl_vo_open_so.php';
require __DIR__.DIRECTORY_SEPARATOR.'cl_vo_emp.php';

 \Slim\Slim::registerAutoloader();
 
// Instantiate a Slim Application
 $app = new \Slim\Slim();
// Set Name of App to identify the app while acquiring references
 $app ->setName(cl_RMGTool_Globals::GC_APP_NAME);
 
// Define a HTTP GET Route
 $app->
            get(cl_RMGTool_Globals ::GC_ROUTE_OPEN_SO, 
               function () use ($app)
               {
                    $lv_so_from_date = $app->request->get(cl_vo_open_so::C_FNAME_SO_FROM);
                    $lv_so_to_date   = $app->request->get(cl_vo_open_so::C_FNAME_SO_TO);
                    $lt_open_so = cl_vo_open_so::get($lv_so_from_date, $lv_so_to_date);
//                    $lt_open_so = cl_vo_open_so::get('2015-08-25', '2015-09-22');
           
           
                    $app->response->setStatus(200);
                    $app->response->headers->set('Content-Type', 'application/json');
                    echo json_encode($lt_open_so, JSON_PRETTY_PRINT);
           
               }
               );
               
               
  $app->
            get(cl_RMGTool_Globals ::GC_SINGLE_EMP, 
               function () use ($app)
               {
                
                    $lv_so_no = $app->request->get("so_no");
                    $lv_skill   = $app->request->get("Skill");
                    $lv_loc = $app->request->get("loc");
                    $lv_level = $app->request->get("level");
                    $lv_sdate = $app->request->get("sdate");
                    $lv_edate = $app->request->get("edate");
                    
                    
                    $lt_emp = cl_vo_deployablEmployee::get($lv_so_no,$lv_skill , $lv_loc, $lv_level,$lv_sdate , $lv_edate);
//                    

                    $app->response->setStatus(200);
                    $app->response->headers->set('Content-Type', 'application/json');
                    echo json_encode($lt_emp, JSON_PRETTY_PRINT);
               }
               );
               
               
     $app->
            get(cl_RMGTool_Globals ::GC_ROUTE_DEPLOYABLE_EMPS, 
               function () use ($app)
               {
                $lv_so_from_date = $app->request->get(cl_vo_open_so::C_FNAME_SO_FROM);
                    $lv_so_to_date   = $app->request->get(cl_vo_open_so::C_FNAME_SO_TO);
                    
                    $lt_emps = cl_vo_deployablEmployee::get_emps($lv_so_from_date,$lv_so_to_date);
                    $app->response->setStatus(200);
                    $app->response->headers->set('Content-Type', 'application/json');
                    echo json_encode($lt_emps, JSON_PRETTY_PRINT);
                    
               }
               );          
               
               
               
               
 $app->get('/deployable_emps/:prime_skill,:level,:', 
               function ($from_date = 3 , $to_date = 4) 
               {
                    echo 'Hello'.$from_date.'--'.$to_date;
               }
    );

//Run the Slim application:
$app->run();
?>

