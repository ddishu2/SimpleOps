<?php
class cl_DB
{
    const DB_EXCEPTION = "Could not connect to database";
    const C_DATE_FORMAT = 'Y-m-d';
    const C_DATE_INITIAL = '0000-00-00';
    const C_QUERY_ERROR  = 'Error: No Records Found';
    const C_HOSTNAME = "localhost";
    const C_DB_NAME = "rmg_tool";
    const C_USER_NAME = "root";
    const C_PASSWORD = "";

    private static $dbhandle = null;
    private static $query_result = null;
    private static $connected_flag = false;

    function __construct()
  {
      self::setDBHandle();
  }
  
  function __destruct()
  {
      self::closeDBHandle();
  }
  
  private static function setDBHandle()
  {
      if(is_null(self::$dbhandle))
      {
        self::$dbhandle = mysqli_connect(self::C_HOSTNAME, self::C_USER_NAME, self::C_PASSWORD, self::C_DB_NAME);
        if (mysqli_connect_errno()) 
        {
            throw new Exception(self::DB_EXCEPTION);
        }
        else
        {
            self::$connected_flag =  true;
        }
     } 
  }
  
  static private function closeDBHandle()
  {
    if(!is_null(self::$dbhandle))
     {
        mysqli_close(self::$dbhandle);
     }
     self::$connected_flag = false;      
  }
  
  public function getDBHandle()
  {
      if(is_null(self::$dbhandle))
      {
         self::setDBHandle();
      }
      return self::$dbhandle;
  }    
  public function getConnectionStatus()
  {
      return self::$connected_flag;
  }  
  
  static function getDBName() 
  {
      return self::$mysql_database;
  }
  
  public function getResultsFromQuery($fp_v_query)
  {
      self::setDBHandle();
      $lv_query_results = self::$dbhandle->query($fp_v_query);
      $re_result['count'] = $lv_query_results->num_rows;
      if(is_null($re_result['count'])||$re_result['count'] == 0)
      {
        $re_result['message'] = self::C_QUERY_ERROR;
      }
      else
      {
        $re_result['message'] = 'Success:'.$re_result['count'].' records found';
      }
      while($row = $lv_query_results->fetch_assoc())
      {
        $re_result[] = $row;
      }
      
      /* free result set */
      $lv_query_results->free();
      
      return $re_result; 
  }
}
