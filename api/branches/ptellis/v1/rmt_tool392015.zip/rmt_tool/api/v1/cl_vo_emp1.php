<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of cl_vo_emp
 *
 * @author ptellis
 */
class cl_vo_deployablEmployee {
    
    
    
    static public function get(     $fp_so_id        = null,
                                    $fp_arr_skill    = null,
                                    $fp_arr_location = null, 
                                    $fp_arr_level    = null, 
                                    $fp_startdate    = null, 
                                    $fp_enddate      = null
                                    
                                )
    {
            
    }
    
    public function __construct($fp_v_empid)
    {
        
    }
    
    public function validate()
    {
        
    }
    
    public function isDeployable()
    {
        
    }
    
    private function isEmpIDValid()
    {
        
    }
    
    public function amendStartDate()
    {
        
    }
    
    public function amendEndDate()
    {
        
    }
    
    public function amend_T_and_E()
    {
        
    }
    
    public function amend_skill() {
        
    }

}
