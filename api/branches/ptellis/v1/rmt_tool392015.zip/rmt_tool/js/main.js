$(function(){
	$(".header .std_buttons").click(function(){
		$(".header .std_buttons").removeClass("selected");
		$(this).addClass("selected");
		
		var index = $(this).index();
		if(index == 0){
			location.href = "demand_fullfill.html";
		} else if(index==1){
			location.href = "report_generation.html";
		} else if(index==2){
			//location.href = "maintenance.html";
		} else if(index==3){
			//location.href = "amendments.html";
		}
		
	});
});
